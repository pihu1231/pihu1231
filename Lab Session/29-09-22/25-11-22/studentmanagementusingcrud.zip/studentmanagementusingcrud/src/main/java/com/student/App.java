package com.student;

import java.util.List;

import com.dao.StudentDao;
import com.entity.Student;
import com.entity.StudentDetail;

public class App 
{
    public static void main( String[] args )
    {
        // Save two instructors
        Student student = new Student("Aditya", "Kumar", "ak6113132@gmail.com");
        StudentDetail studentDetail = new StudentDetail(21,"piano");
        studentDetail.setStudent(student);
        student.setStudentDetail(studentDetail);
       
        Student student1 = new Student("Luv", "Kumar", "luv02@gmail,com");
        StudentDetail studentDetail1 = new StudentDetail(22, "Guitar");
        studentDetail1.setStudent(student1);
        student1.setStudentDetail(studentDetail1);
       
        StudentDao studentDao = new StudentDao();
        studentDao.saveStudent(student);
        studentDao.saveStudent(student1);
       
        // Get all instructors
        List<Student> students = studentDao.getAllStudent();
        students.forEach(studentTemp -> System.out.println(studentTemp.getFirstName()));
    }
}

