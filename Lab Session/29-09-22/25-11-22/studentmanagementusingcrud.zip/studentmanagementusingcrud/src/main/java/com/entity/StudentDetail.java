package com.entity;
import jakarta.persistence.*;


@Entity
@Table(name="student_detail")
public class StudentDetail {
    
	
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    
    //variables
    @Column(name="id")
    private int id;
    
    @Column(name="student_age")
    private int age;
    
    @Column(name="hobby")
    private String hobby;
    
    @OneToOne(mappedBy="studentDetail", cascade=CascadeType.ALL)
    private Student student;

	
    
    //default constructor
    public StudentDetail() {
        
    }

 
    //Parameterized Constructor
    public StudentDetail(int age, String hobby) {
        this.age = age;
        this.hobby = hobby;
    }

 
    //getter & setter
    public int getId() {
        return id;
    }

 

    public void setId(int id) {
        this.id = id;
    }

 

    public int getStudentage() {
		return age;
    }

 

    public void setStudentage(int age) {
        this.age = age;
    }

 

    public String getHobby() {
        return hobby;
    }

 

    public void setHobby(String hobby) {
        this.hobby = hobby;
    }
    
    public Student getStudent() {
        return student;
    }

 

    public void setStudent(Student student) {
        this.student = student;
    }

 

    @Override
    public String toString() {
        return "StudentDetail [id=" + id + ", student age=" + age+ ", hobby=" + hobby + "]";
    }
}


