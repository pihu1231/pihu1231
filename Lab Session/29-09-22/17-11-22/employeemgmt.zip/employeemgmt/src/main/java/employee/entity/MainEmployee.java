package employee.entity;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="PROJECTS")
public class MainEmployee {
	@Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="PR_ID", unique = true, nullable = false)
    private Long prId;
 
    private String name;
 
    private String owner;
 
    @ManyToMany(mappedBy = "empAssignmentList")
    private List<Employee> employees;
 
    @Override
    public String toString() {
 
        return this.prId +" | "+ this.name +" | "+ this.owner;
    }
 
    public Long getPrId() {
        return prId;
    }
 
    public void setPrId(Long prId) {
        this.prId = prId;
    }
 
    public String getName() {
        return name;
    }
 
    public void setName(String name) {
        this.name = name;
    }
 
    public String getOwner() {
        return owner;
    }
 
    public void setOwner(String owner) {
        this.owner = owner;
    }
}
