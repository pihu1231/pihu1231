package com.junit;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class BasicSalaryCaculatorTest {

	private BasicSalaryCaculator basicSalaryCalculator;
	@BeforeEach
//	void init()
//	{
//		 basicSalaryCalculator = new BasicSalaryCaculator();
//	}
@Test
void testBasicSalaryWithValidSalary()
{
	double basicSalary=4000;
	basicSalaryCalculator.setBasicSalary(basicSalary);
	
}
}
